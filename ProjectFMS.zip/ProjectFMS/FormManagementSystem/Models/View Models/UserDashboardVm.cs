﻿namespace FormManagementSystem.Models.View_Models
{
    public class UserDashboardVm
    {
        public IEnumerable<Form> ActiveForms { get; set; }
        public IEnumerable<FormSubmissionMeta> UserSubmissions { get; set; }
    }
}
