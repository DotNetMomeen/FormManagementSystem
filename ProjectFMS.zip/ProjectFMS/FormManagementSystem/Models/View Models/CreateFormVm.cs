﻿namespace FormManagementSystem.Models.View_Models
{
    public class CreateFormVm
    {
        [Required]
        public string Name { get; set; }
        public string Description { get; set; }
        public DateTime? Deadline { get; set; }
        public List<FormFieldVm> Fields { get; set; } = new List<FormFieldVm>();
    }

}
