﻿namespace FormManagementSystem.Models.View_Models
{
    public class AdminDashboardVm
    {
        public int TotalSubmissions { get; set; }
        public int ActiveFormsCount { get; set; }
        public int TotalUsers { get; set; }
        public IEnumerable<Form> ActiveForms { get; set; }
    }
}
