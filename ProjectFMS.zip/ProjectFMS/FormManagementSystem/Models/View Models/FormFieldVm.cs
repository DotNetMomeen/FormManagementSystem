﻿namespace FormManagementSystem.Models.View_Models
{
    public class FormFieldVm
    {
        [Required]
        public string Label { get; set; }
        [Required]
        public FieldDataType DataType { get; set; }
        public bool IsRequired { get; set; }
        public string Options { get; set; }
        public int ColumnOrder { get; set; }
        public int RowNumber { get; set; }
    }
}
