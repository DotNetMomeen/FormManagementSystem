﻿namespace FormManagementSystem.Models
{
    public class FormFieldViewModel
    {
        public string FieldLabel { get; set; }
        public string DataType { get; set; }
        public bool IsRequired { get; set; }
        public string Options { get; set; }
    }
}
