﻿using System.ComponentModel.DataAnnotations;

namespace FormManagementSystem.Models
{
    public class FormField
    {
        public int Id { get; set; }
        public int FormId { get; set; }
        public virtual Form Form { get; set; }
        [Required]
        public string Label { get; set; }
        public string FieldName { get; set; }
        public FieldDataType DataType { get; set; }
        public bool IsRequired { get; set; }
        public string OptionsJson { get; set; }
        public int ColumnOrder { get; set; }
        public int RowNumber { get; set; }
    }
}
