﻿namespace FormManagementSystem.Models
{
    public class FormSubmissionMeta
    {
        public int Id { get; set; }
        public int FormId { get; set; }
        public virtual Form Form { get; set; }
        public string UserId { get; set; }
        public virtual ApplicationUser User { get; set; }
        public DateTime SubmittedAt { get; set; }
        public string SubmissionReference { get; set; }
    }
}
