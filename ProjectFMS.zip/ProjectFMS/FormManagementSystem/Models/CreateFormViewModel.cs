﻿namespace FormManagementSystem.Models
{
    public class CreateFormViewModel
    {
        [Required]
        public string Name { get; set; }
        public string Description { get; set; }
        public DateTime? Deadline { get; set; }
        public bool IsActive { get; set; }
        public List<FormFieldViewModel> Fields { get; set; } = new List<FormFieldViewModel>();
    }
}
