﻿using Microsoft.Data.SqlClient;
using System.Text;

namespace FormManagementSystem.Models

{
    public class FormTableService
    {
        private readonly string _conn;
        public FormTableService(IConfiguration cfg)
        {
            _conn = cfg.GetConnectionString("DefaultConnection");
        }

        private string SanitizeIdentifier(string input)
        {
            if (string.IsNullOrWhiteSpace(input)) throw new ArgumentException("Invalid identifier");
            var cleaned = System.Text.RegularExpressions.Regex.Replace(input, "[^A-Za-z0-9_]", "");
            if (!System.Text.RegularExpressions.Regex.IsMatch(cleaned, "^[A-Za-z]")) cleaned = "A" + cleaned;
            return cleaned;
        }

        private string SqlTypeFor(FieldDataType dt)
        {
            return dt switch
            {
                FieldDataType.Text => "NVARCHAR(1000)",
                FieldDataType.Number => "DECIMAL(18,4)",
                FieldDataType.Date => "DATETIME2",
                FieldDataType.Dropdown => "NVARCHAR(500)",
                FieldDataType.Checkbox => "BIT",
                FieldDataType.File => "NVARCHAR(500)",
                _ => "NVARCHAR(1000)"
            };
        }

        public async Task CreateTableForFormAsync(Form form, IEnumerable<FormField> fields)
        {
            var tableName = SanitizeIdentifier(form.TableName);
            var sb = new StringBuilder();
            sb.Append($"CREATE TABLE [{tableName}] (");
            sb.Append("[Id] INT IDENTITY(1,1) PRIMARY KEY, [UserId] NVARCHAR(450), [SubmittedAt] DATETIME2, ");
            foreach (var f in fields.OrderBy(f => f.ColumnOrder))
            {
                var col = SanitizeIdentifier(f.FieldName);
                var sqlType = SqlTypeFor(f.DataType);
                var notNull = f.IsRequired ? "NOT NULL" : "NULL";
                sb.Append($"[{col}] {sqlType} {notNull}, ");
            }
            var sql = sb.ToString().TrimEnd(' ', ',') + ");";

            using var conn = new SqlConnection(_conn);
            await conn.ExecuteAsync(sql);
        }

        public async Task<int> InsertSubmissionAsync(string tableName, string userId, Dictionary<string, object> values)
        {
            var tn = SanitizeIdentifier(tableName);
            var cols = string.Join(", ", values.Keys.Select(k => $"[{SanitizeIdentifier(k)}]"));
            var paramNames = string.Join(", ", values.Keys.Select((k, i) => $"@p{i}"));
            var sql = $"INSERT INTO [{tn}] ([UserId],[SubmittedAt], {cols}) VALUES (@userId, @submittedAt, {paramNames}); SELECT SCOPE_IDENTITY();";

            var parameters = new DynamicParameters();
            parameters.Add("userId", userId);
            parameters.Add("submittedAt", DateTime.UtcNow);

            int i = 0;
            foreach (var value in values.Values)
            {
                parameters.Add($"p{i}", value);
                i++;
            }

            using var conn = new SqlConnection(_conn);
            return await conn.ExecuteScalarAsync<int>(sql, parameters);
        }

        public async Task<dynamic> GetSubmissionAsync(string tableName, int submissionId)
        {
            var tn = SanitizeIdentifier(tableName);
            var sql = $"SELECT * FROM [{tn}] WHERE Id = @id";

            using var conn = new SqlConnection(_conn);
            return await conn.QueryFirstOrDefaultAsync(sql, new { id = submissionId });
        }

        public async Task<IEnumerable<dynamic>> GetAllSubmissionsAsync(string tableName)
        {
            var tn = SanitizeIdentifier(tableName);
            var sql = $"SELECT * FROM [{tn}] ORDER BY SubmittedAt DESC";

            using var conn = new SqlConnection(_conn);
            return await conn.QueryAsync(sql);
        }
    }
}
