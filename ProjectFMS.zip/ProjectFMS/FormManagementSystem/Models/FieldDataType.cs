﻿namespace FormManagementSystem.Models
{
    public enum FieldDataType
    {
        Text,
        Number,
        Date,
        Dropdown,
        Checkbox,
        File
    }
}
