﻿using FormManagementSystem.Application_Data;
using FormManagementSystem.FormRepository;
using FormManagementSystem.Models;
using FormManagementSystem.Models.View_Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace FormManagementSystem.Controllers
{
    [Authorize]
    public class FormsController : Controller
    {
        private readonly IFormRepository _forms;
        private readonly FormTableService _tableService;
        private readonly ApplicationDbContext _db;
        private readonly UserManager<ApplicationUser> _userManager;

        public FormsController(IFormRepository forms, FormTableService tableService, ApplicationDbContext db, UserManager<ApplicationUser> userManager)
        {
            _forms = forms;
            _tableService = tableService;
            _db = db;
            _userManager = userManager;
        }

        public async Task<IActionResult> Index()
        {
            var forms = await _forms.GetActiveFormsAsync();
            var userId = _userManager.GetUserId(User);

            var model = new UserDashboardVm
            {
                ActiveForms = forms,
                UserSubmissions = await _db.FormSubmissionMetas
                    .Where(s => s.UserId == userId)
                    .Include(s => s.Form)
                    .ToListAsync()
            };

            return View(model);
        }

        [HttpGet]
        public async Task<IActionResult> Fill(int id)
        {
            var form = await _forms.GetByIdAsync(id);
            if (form == null) return NotFound();

            if (!form.IsActive) return BadRequest("Form not active");
            if (form.Deadline.HasValue && DateTime.UtcNow > form.Deadline.Value)
                return View("FormExpired", form);

            return View(form);
        }

        [HttpPost]
        public async Task<IActionResult> Fill(int id, IFormCollection fc)
        {
            var form = await _forms.GetByIdAsync(id);
            if (form == null) return NotFound();

            if (form.Deadline.HasValue && DateTime.UtcNow > form.Deadline.Value)
                return BadRequest("Deadline passed");

            // Build values dictionary
            var values = new Dictionary<string, object>();
            foreach (var f in form.Fields)
            {
                var v = fc[f.FieldName].ToString();
                if (string.IsNullOrEmpty(v) && f.IsRequired)
                    ModelState.AddModelError(f.FieldName, $"{f.Label} is required");

                object converted = v;
                if (f.DataType == FieldDataType.Number)
                    converted = decimal.TryParse(v, out var d) ? d : (object)null;
                if (f.DataType == FieldDataType.Date)
                    converted = DateTime.TryParse(v, out var dt) ? dt : (object)null;
                if (f.DataType == FieldDataType.Checkbox)
                    converted = !string.IsNullOrEmpty(v) && v.Equals("on");

                values[f.FieldName] = converted ?? DBNull.Value;
            }

            if (!ModelState.IsValid)
                return View(form);

            // Insert into dynamic table
            var userId = _userManager.GetUserId(User);
            var submissionId = await _tableService.InsertSubmissionAsync(form.TableName, userId, values);

            // Save meta
            var meta = new FormSubmissionMeta
            {
                FormId = form.Id,
                UserId = userId,
                SubmittedAt = DateTime.UtcNow,
                SubmissionReference = submissionId.ToString()
            };

            _db.FormSubmissionMetas.Add(meta);
            await _db.SaveChangesAsync();

            return RedirectToAction("SubmissionSuccess", new { id = submissionId });
        }

        [HttpGet]
        public async Task<IActionResult> ViewSubmission(int formId, int submissionId)
        {
            var form = await _forms.GetByIdAsync(formId);
            if (form == null) return NotFound();

            var userId = _userManager.GetUserId(User);
            var submission = await _tableService.GetSubmissionAsync(form.TableName, submissionId);

            if (submission == null) return NotFound();

            // Check if user owns this submission or is admin
            var dict = (IDictionary<string, object>)submission;
            if (dict["UserId"].ToString() != userId && !User.IsInRole("Admin"))
                return Forbid();

            ViewBag.Form = form;
            return View(submission);
        }

        public IActionResult SubmissionSuccess(int id)
        {
            ViewBag.SubmissionId = id;
            return View();
        }
    }
}
