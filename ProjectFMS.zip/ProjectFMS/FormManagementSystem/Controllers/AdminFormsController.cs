﻿using FormManagementSystem.FormRepository;
using FormManagementSystem.Models;
using FormManagementSystem.Models.View_Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FormManagementSystem.Controllers
{
    [Authorize(Roles = "Admin")]
    public class AdminFormsController : Controller
    {
            private readonly IFormRepository _forms;
            private readonly FormTableService _tableService;
            private readonly UserManager<ApplicationUser> _userManager;

            public AdminFormsController(IFormRepository forms, FormTableService tableService, UserManager<ApplicationUser> userManager)
            {
                _forms = forms;
                _tableService = tableService;
                _userManager = userManager;
            }

            public async Task<IActionResult> Dashboard()
            {
                var model = new AdminDashboardVm
                {
                    TotalSubmissions = await _forms.GetTotalSubmissionsAsync(),
                    ActiveFormsCount = await _forms.GetActiveFormsCountAsync(),
                    ActiveForms = await _forms.GetActiveFormsAsync(),
                    TotalUsers = _userManager.Users.Count()
                };
                return View(model);
            }

            [HttpGet]
            public IActionResult Create() => View();

            [HttpPost]
            public async Task<IActionResult> Create(CreateFormVm vm)
            {
                if (!ModelState.IsValid) return View(vm);

                var form = new Form
                {
                    Name = vm.Name,
                    Description = vm.Description,
                    CreatedAt = DateTime.UtcNow,
                    IsActive = false,
                    TableName = "Form_" + Guid.NewGuid().ToString("N"),
                    CreatedById = _userManager.GetUserId(User)
                };

                await _forms.AddAsync(form);

                // Save fields
                for (int i = 0; i < vm.Fields.Count; i++)
                {
                    var fieldVm = vm.Fields[i];
                    var field = new FormField
                    {
                        FormId = form.Id,
                        Label = fieldVm.Label,
                        FieldName = $"field_{i}_{SanitizeFieldName(fieldVm.Label)}",
                        DataType = fieldVm.DataType,
                        IsRequired = fieldVm.IsRequired,
                        OptionsJson = fieldVm.Options,
                        ColumnOrder = fieldVm.ColumnOrder,
                        RowNumber = fieldVm.RowNumber
                    };
                    await _forms.AddFieldAsync(field);
                }

                return RedirectToAction("Edit", new { id = form.Id });
            }

            [HttpGet]
            public async Task<IActionResult> Edit(int id)
            {
                var form = await _forms.GetByIdAsync(id);
                if (form == null) return NotFound();

                return View(form);
            }

            [HttpPost]
            public async Task<IActionResult> Activate(int id, DateTime deadline)
            {
                var form = await _forms.GetByIdAsync(id);
                if (form == null) return NotFound();

                form.Deadline = deadline.ToUniversalTime();
                await _tableService.CreateTableForFormAsync(form, form.Fields);
                form.IsActive = true;

                await _forms.UpdateAsync(form);
                return RedirectToAction("Dashboard");
            }

            [HttpPost]
            public async Task<IActionResult> ExtendDeadline(int id, DateTime newDeadline)
            {
                var form = await _forms.GetByIdAsync(id);
                if (form == null) return NotFound();

                form.Deadline = newDeadline.ToUniversalTime();
                await _forms.UpdateAsync(form);

                return RedirectToAction("Dashboard");
            }

            public async Task<IActionResult> Submissions(int id)
            {
                var form = await _forms.GetByIdAsync(id);
                if (form == null) return NotFound();

                var submissions = await _tableService.GetAllSubmissionsAsync(form.TableName);
                ViewBag.Form = form;

                return View(submissions);
            }

            public async Task<IActionResult> ExportSubmissions(int id)
            {
                var form = await _forms.GetByIdAsync(id);
                if (form == null) return NotFound();

                var submissions = await _tableService.GetAllSubmissionsAsync(form.TableName);

                // Generate Excel file (simplified)
                var csv = "UserId,SubmittedAt," + string.Join(",", form.Fields.OrderBy(f => f.ColumnOrder).Select(f => f.Label)) + "\n";

                foreach (var submission in submissions)
                {
                    var dict = (IDictionary<string, object>)submission;
                    csv += $"{dict["UserId"]},{dict["SubmittedAt"]},";

                    foreach (var field in form.Fields.OrderBy(f => f.ColumnOrder))
                    {
                        var value = dict.ContainsKey(field.FieldName) ? dict[field.FieldName]?.ToString() : "";
                        csv += $"\"{value}\",";
                    }

                    csv = csv.TrimEnd(',') + "\n";
                }

                return File(System.Text.Encoding.UTF8.GetBytes(csv), "text/csv", $"{form.Name}_submissions.csv");
            }

            private string SanitizeFieldName(string input)
            {
                if (string.IsNullOrWhiteSpace(input)) return "field";
                var cleaned = System.Text.RegularExpressions.Regex.Replace(input, "[^A-Za-z0-9]", "");
                if (string.IsNullOrWhiteSpace(cleaned)) return "field";
                return cleaned;
            }
        
    }
}
