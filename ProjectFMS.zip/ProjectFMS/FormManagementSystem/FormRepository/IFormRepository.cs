﻿using FormManagementSystem.Models;

namespace FormManagementSystem.FormRepository
{
    public interface IFormRepository
    {
        Task<Form> GetByIdAsync(int id);
        Task<IEnumerable<Form>> GetAllAsync();
        Task<IEnumerable<Form>> GetActiveFormsAsync();
        Task<int> AddAsync(Form form);
        Task UpdateAsync(Form form);
        Task DeleteAsync(int id);
        Task AddFieldAsync(FormField field);
        Task<int> GetSubmissionCountAsync(int formId);
        Task<int> GetTotalSubmissionsAsync();
        Task<int> GetActiveFormsCountAsync();
        Task<bool> ExtendDeadlineAsync(int formId, DateTime newDeadline);
        Task<IEnumerable<FormSubmissionMeta>> GetSubmissionsForFormAsync(int formId);
    }
}
