﻿using FormManagementSystem.Models;

namespace FormManagementSystem.FormRepository
{
    public class FormRepository : IFormRepository
    {
        private readonly ApplicationDbContext _context;

        public FormRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<Form> GetByIdAsync(int id)
        {
            return await _context.Forms
                .Include(f => f.Fields)
                .Include(f => f.Submissions)
                .FirstOrDefaultAsync(f => f.Id == id);
        }

        public async Task<IEnumerable<Form>> GetActiveFormsAsync()
        {
            return await _context.Forms
                .Where(f => f.IsActive && (!f.Deadline.HasValue || f.Deadline > DateTime.UtcNow))
                .Include(f => f.Fields)
                .OrderBy(f => f.Deadline)
                .ToListAsync();
        }

        public async Task<int> AddAsync(Form form)
        {
            _context.Forms.Add(form);
            await _context.SaveChangesAsync();
            return form.Id;
        }

        public async Task UpdateAsync(Form form)
        {
            _context.Forms.Update(form);
            await _context.SaveChangesAsync();
        }

        public async Task AddFieldAsync(FormField field)
        {
            _context.FormFields.Add(field);
            await _context.SaveChangesAsync();
        }

        public async Task<int> GetTotalSubmissionsAsync()
        {
            return await _context.FormSubmissionMetas.CountAsync();
        }

        public async Task<int> GetActiveFormsCountAsync()
        {
            return await _context.Forms.CountAsync(f => f.IsActive && (!f.Deadline.HasValue || f.Deadline > DateTime.UtcNow));
        }

        public async Task<IEnumerable<FormSubmissionMeta>> GetSubmissionsForFormAsync(int formId)
        {
            return await _context.FormSubmissionMetas
                .Where(s => s.FormId == formId)
                .Include(s => s.User)
                .ToListAsync();
        }

        // Other implementations...
    }
}
