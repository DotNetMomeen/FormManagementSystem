﻿using FormManagementSystem.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace FormManagementSystem.Application_Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<Form> Forms { get; set; }
        public DbSet<FormField> FormFields { get; set; }
        public DbSet<FormSubmissionMeta> FormSubmissionMetas { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
            builder.Entity<Form>().HasMany(f => f.Fields).WithOne(ff => ff.Form).HasForeignKey(ff => ff.FormId);
            builder.Entity<FormSubmissionMeta>().HasOne<Form>().WithMany().HasForeignKey(f => f.FormId);
            builder.Entity<FormSubmissionMeta>().HasOne<ApplicationUser>().WithMany().HasForeignKey(f => f.UserId);
        }
    }
}
